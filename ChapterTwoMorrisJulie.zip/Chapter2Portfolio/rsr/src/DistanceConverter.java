package src;



public class DistanceConverter {
	/* Assignment:
	 * You want to know how many feet are in 3.5 yards, and how many inches are in 
	 * 3.5 yards. You write the following program for that purpose:
	 */
	
	public static void main (String[] args) {
		//These two variables show that there are 3 feet in a yard and 36 inches in a yard.
		int FeetYard = 3;
		int InchYard = 36;
		double yards = 3.5; //the starting yards
		double feet = yards * FeetYard; //gives the amount of feet in 3.5 yards
		double inches = feet * InchYard;// gives the amount of inches in 3.5 yards
		//TODO Rewrite Code.
		System.out.println(yards + " yards are " + feet + " feet");
		System.out.println(yards + " yards are " + inches + " inches");
	}
}

/*   a. The problem with the code above is that using "magic numbers" makes the program 
 *      hard to debug and maintain. Modify the program so that it uses constants to improve
 *      legibility and makes it easier to maintain.
 *   b. Add chunking and comments to enhance the readability. Don't forget comments!
 *   c. Should any of the variables actually be constants? If so, fix them.
 *   d. Check and fix the indentation.
 *   e. Run the program. Make changes to the program so the output is more readable.
 */