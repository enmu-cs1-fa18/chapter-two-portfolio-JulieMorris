package src;


/**
 * Extracts a particular string from a longer one.
 * @author Julie Morris
 * @version 1
 * @date 9/16/2018
 *
 */
public class StringExtractor {
	 /* 
	 * Assignment:
	 * 1. Using any of the string methods, write a sequence of commands that will extract 
	 *    characters from final String inputString = "The quick brown fox jumps over the lazy dog." to make
	 *    outputString = "Tempus fugit.". Then print inputString and outputString. Be sure to add some 
	 *    text so we know what has been done! 
	 *    
	 *    Correct any style, runtime, or compiler errors in the starter code.
	 */
	public static void main(String[] args) {
		final String inputString = "The quick brown fox jumps over the lazy dog.";
		final String outputString = "Tempus fugit.";		
		
		// This print statement involves substrings.
		// When using a substring, the letter we want to appear in the output is placed first and the number 
		// after is the number where the substring will stop and not include the character at that letter.
		// A string starts at 0 and spaces and any punctuation are counted.
		// The plus signs concat the substrings of the inputString to form the outputString.
		
		System.out.println("The input string: " + inputString);
		System.out.println("The String Extractor: " + inputString.substring(0,1) + inputString.substring(2,3)
				+ inputString.substring(22,24) + inputString.substring(21,22) + inputString.substring(24,25)
				+ " " + inputString.substring(16, 17) + inputString.substring(5,6) 
				+ inputString.substring(42,43) + inputString.substring(6,7) + inputString.substring(31,32) 
				+ ".");
		System.out.println("The output string:" + outputString);
		
				
		
		
	}

}
