package src;



/**
 * Calculates how many full cases can be filled with a given number of cans.
 * 
 * @author Julie Morris
 * @version:1
 * @date 9/16/2018
 */
public class CaseCounter {
	/*
	 * SPECIFICATIONS:
	 * You have 457 cans and a case holds 12 cans. 
	 * Print out how many full cases you will have. 
	 * Print out how many cans are left over. 
	 * (Should 457 and 12 be constants or be typed into the code?)
	 */
	
	/**
	 * The main method where you will execute your code.
	 * @param args
	 */
	public static void main(String[] args) {
		int cans = 457; // initial amount of cans
		int cansCases = 12; // amount of cans each case can hold
		int fullCases; // the tracker for how many cases are full
		int cansLeft; // the tracker for how many cans are left
		
		fullCases = cans/cansCases; // to find fullCases divide cans by cansCases
		cansLeft = fullCases % 10; // modulus 10 finds the remainder or cans left (if its a decimal, it rounds down due to integer division)
		System.out.println("Full Cases: " + fullCases); //prints out the number of full cases
		System.out.println("Cans left: " + cansLeft); // prints out the number of cans left
		

	}

}
