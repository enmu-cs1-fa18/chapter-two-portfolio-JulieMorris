package src;

import java.util.Scanner;

/**
 * Gets words from user to fill in the gaps in a story.
 * @author Julie Morris
 * @version 1
 * @date 9/16/2018
 *
 */
public class MadLibber {

	public static void main(String[] args) {
		Scanner output = new Scanner(System.in); // Scanners allow users to put in inputs
		System.out.println("Enter an Adjective:"); //These print statements ask the user to enter in the words
		String Adj1 = output.next(); // This statement has the users words read in 
		System.out.println("Enter a Noun:");
		String Noun1 = output.next();
		System.out.println("Enter a Number:");
		int Number1 = output.nextInt();
		System.out.println("Enter a Noun:");
		String Noun2 = output.next();
		System.out.println("Enter an Adjective:");
		String Adj2 = output.next();
		System.out.println("Enter a Verb:");
		String Verb1 = output.next();
		System.out.println("Enter a Noun:");
		String Noun3 = output.next();
		System.out.println("Enter a Bodypart:");
		String Bodypart1 = output.next();
		
		System.out.println("Hey baby, I guarantee there'll be " + Adj1 + " times. I guarantee that at some\r\n" + 
			Noun1 + ", " + Number1 + " or both of us is gonna want to get out of this " + Noun2 + ". But\r\n" + 
				"I also guarantee that if I don't ask you to be " + Adj2 + ", I'll " + Verb1 + " it for the\r\n" + 
				"rest of my " + Noun3 + ", because I know in my " + Bodypart1 + ", you're the only one for me.");
		//This print statement places the words into the statement.

	}

}
