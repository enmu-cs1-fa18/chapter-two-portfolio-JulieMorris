package src;

/**
 * Calculates and prints the distance between two points.
 * @author Julie Morris
 * @version 1
 * @date 9/16/18
 *
 */
public class DistanceFormula {
	/*
	 * SPECIFICATIONS:
	 * Distance Formula: d=square root((x1-x2)^2+(y1-y2)^2 ), where (x1,y1 )  and (x2,y2 ) are 
	 * the two ordered pairs. 
	 * Find the distance between (6, 7) and (-3, -2) using the distance formula. 
	 * For extra credit, round the distance to the nearest hundredth using java. 
	 * Print an additional statement to report the rounded distance.
	 */
	
	/**
	 * The main method where you will execute your code.
	 * @param args
	 */
	public static void main(String[] args) {
		//TODO Write Code.
		double distance;
		double roundedDistance;
		double x1 = 6;
		double y1 = 7;
		double x2 = -3;
		double y2 = -2;
		
		distance = Math.sqrt(Math.pow((x1-x2),2) + Math.pow((y1-y2), 2));
		System.out.println("The distance is: " + distance);
		roundedDistance = Math.round(Math.sqrt(Math.pow((x1-x2),2) + Math.pow((y1-y2), 2)) * 100.0)/100.0;
		System.out.println("The rounded distance is: " + roundedDistance);
	}

}
