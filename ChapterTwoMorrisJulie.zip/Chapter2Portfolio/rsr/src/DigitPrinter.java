package src;
/**
 * Takes any number up to 3 digits and print out each digit individually.
 * 
 * @author Julie Morris
 * @version: 1
 * @date 9/16/2018
 *
 */
public class DigitPrinter {

	/**
	 * The main method where you will execute your code.
	 * @param args
	 */
	public static void main(String[] args) {
		//TODO Write Code.
		final int MY_NUMBER = 349;
		int firstNumber;
		int secondNumber;
		int thirdNumber;
		
		firstNumber = MY_NUMBER / 100; //Gets the number from the hundreds place
		secondNumber = MY_NUMBER % 100 / 10;//the modulus of 349 and 100 is 49, divided by 10 is 4(int div)
		thirdNumber = MY_NUMBER % 10; // this gets the number from the ones place
		
		System.out.println("The first number is: " + firstNumber);
		System.out.println("The number in the tens place is: " + secondNumber);
		System.out.println("The third number is: " + thirdNumber);
	}

}
