package src;

import java.util.Scanner;

/**
 * Calculates how many full cases can be filled with a given number of cans.
 * 
 * @author Julie Morris
 * @version 1
 * @date 9/20/2018
 */
public class CaseCounterEnhanced {
	
	/**
	 * The main method where you will execute your code.
	 * @param args
	 */
	public static void main(String[] args) {
		int cans; 
		int fullCases;
		int cansLeft;
		double costCan;
		double totalDollar;
		Scanner input = new Scanner (System.in); // scanners allow for users to input information into code
		System.out.println("Please enter number of cans: "); //prompts the user to enter cans
		cans = input.nextInt(); // reads that number into the program
		System.out.println("Please insert the cost of a can: "); //prompts user to enter the cost of a can
		costCan = input.nextDouble(); // reads that number into the program
		fullCases = cans / 12; // to find how many full cases, divide the number of cans by how much a full case can hold
		cansLeft = fullCases % 10; // the modulus takes the remainder from the division and that creates the number of cans leftover
		System.out.println("The amount of full cases is: " + fullCases); //prints out the number of full cases
		System.out.println("The amount of cans leftover is: " + cansLeft); // prints out the number of cans left over
		totalDollar =  cans * costCan; //to find the total dollar value, take the number of cans multiplied by the cost of a single can
		System.out.println("The total dollar amount of the cans is: " + "$" + totalDollar); //this statement prints out the total dollar amount of the cans in dollar form
		
	}

}
