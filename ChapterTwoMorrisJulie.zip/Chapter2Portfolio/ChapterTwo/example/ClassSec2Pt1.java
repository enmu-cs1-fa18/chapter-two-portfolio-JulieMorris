

public class ClassSec2Pt1 {

	public static void main(String[] args) {
		// Arithmetic part 1
/*
 * Four Fundamental Operators:
 * Precedence rules (order of operations for Java):
 *   to force a different order:
 * Implicit type casting:
 * Increment and Decrement:
 * Integer Division and Remainder
 *   to find the quotient (w/out remainder):
 * 	 for remainder:
 *   Suppose you have 1729 pennies in your piggy bank. How many dollars do you have? 
 *   How many pennies do you have left over?
 *   */
 // Common uses of Modulus operator:
 //   1.
 //   2. 
 //   3.
 //   4.

	}

}
